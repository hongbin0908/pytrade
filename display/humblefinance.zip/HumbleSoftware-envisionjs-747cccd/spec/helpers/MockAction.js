function MockAction () {
  this.events = [
    {
      handler : 'handle',
      consumer : 'consume'
    },
    'handleConsume'
  ];
}
